# Your Personal — passo a passo

1. **Firebase** (console.firebase.google.com): criar projeto > Authentication: ativar *Google* e *E-mail/senha* > Firestore Database: criar > aba Regras: colar o conteúdo de `firestore.rules` > Configurações do projeto: adicionar app Web e copiar as chaves para `config.js`.
2. **Google Cloud Console** (mesmo projeto) > Credenciais: criar IDs de cliente OAuth *Web*, *Android* (pacote `com.pedroguilherme.yourpersonal` + SHA-1 do build) e *iOS* (bundle id igual). Colar em `config.js` (`G`).
3. No computador: `npm install` e `npx expo start`. Teste no celular com o app Expo Go.
4. Para gerar o app instalável: `npm i -g eas-cli`, `eas login`, `eas init` (cole o projectId em `app.json`), depois:
   - Android (APK para instalar direto): `eas build -p android --profile preview`
   - iOS: `eas build -p ios` (precisa de conta Apple Developer, US$ 99/ano)
5. Publicar nas lojas: `eas submit`.
