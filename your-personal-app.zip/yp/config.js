// Cole aqui as chaves do seu projeto Firebase (Configurações do projeto > Seus apps > Web)
export const firebaseConfig={apiKey:'',authDomain:'',projectId:'',storageBucket:'',messagingSenderId:'',appId:''};
// IDs de cliente OAuth do Google (Google Cloud Console > Credenciais)
export const G={web:'',android:'',ios:''};
